<%
%><%@ include file="/libs/granite/ui/global.jsp" %><%
%><%@ page session="false"
          import="java.util.HashMap,
                  org.apache.sling.api.wrappers.ValueMapDecorator,
                  com.adobe.granite.ui.components.Config,
                  com.adobe.granite.ui.components.Field" %><%

    Config cfg = cmp.getConfig();

    ValueMap vm = new ValueMapDecorator(new HashMap<String, Object>());

    String name = cfg.get("name", String.class);
    vm.put("value", cmp.getValue().getContentValue(name, new String[0]));

    request.setAttribute(Field.class.getName(), vm);
%>