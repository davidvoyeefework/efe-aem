<%
%><%@include file="/libs/granite/ui/global.jsp" %><%
%><%@page session="false"
          import="java.util.Arrays,
                  java.util.Iterator,
                  java.util.List,
                  org.apache.commons.lang3.StringUtils,
                  com.adobe.granite.ui.components.AttrBuilder,
                  com.adobe.granite.ui.components.Config,
                  com.adobe.granite.ui.components.Field,
                  com.adobe.granite.ui.components.Tag,
                  com.adobe.granite.ui.components.Value" %><%

Config cfg = cmp.getConfig();
ValueMap vm = (ValueMap) request.getAttribute(Field.class.getName());

boolean multiple = false;
String name = cfg.get("name", String.class);

Resource values = resource.getChild("values");

Tag tag = cmp.consumeTag();
AttrBuilder attrs = tag.getAttrs();
cmp.populateCommonAttrs(attrs);

attrs.add("name", name);
attrs.add("value", vm.get("value", String.class));
attrs.add("class", "workfront-field-autocomplete");

AttrBuilder deleteAttrs = new AttrBuilder(request, xssAPI);
deleteAttrs.addClass("foundation-field-related");
deleteAttrs.add("type", "hidden");
if (name != null && name.trim().length() > 0) {
    deleteAttrs.add("name", name + "@Delete");
}

%><coral-autocomplete <%= attrs.build() %>><%
    if (cfg.get("deleteHint", true)) {
        %><input <%= deleteAttrs.build() %>><%
    }

    AttrBuilder optionsAttrs = new AttrBuilder(request, xssAPI);
    optionsAttrs.addClass("js-coral-Autocomplete-selectList");

    cmp.include(resource.getChild("options"), new Tag(optionsAttrs));
%></coral-autocomplete>