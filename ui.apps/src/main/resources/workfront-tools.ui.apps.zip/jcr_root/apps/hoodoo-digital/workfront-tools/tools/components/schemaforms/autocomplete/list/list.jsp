<%
%><%@include file="/libs/granite/ui/global.jsp" %><%
%><%@page import="java.util.Iterator,
                  com.adobe.granite.ui.components.AttrBuilder,
                  com.adobe.granite.ui.components.Config,
                  com.adobe.granite.ui.components.ExpressionHelper,
                  com.adobe.granite.ui.components.Tag" %><%

Config cfg = cmp.getConfig();
Config parentCfg = new Config(resource.getParent());
String selectedValue = parentCfg.get("value","");
Tag tag = cmp.consumeTag();
AttrBuilder attrs = tag.getAttrs();
cmp.populateCommonAttrs(attrs);

if (request.getAttribute("hasBuiltAutocomplete") == null || (int) request.getAttribute("hasBuiltAutocomplete") < 8) {
for (Iterator<Resource> items = cmp.getItemDataSource(resource.getParent()).iterator(); items.hasNext();) {
    Resource item = items.next();
    Config itemCfg = new Config(item);


    AttrBuilder itemAttrs = new AttrBuilder(request, xssAPI);
    String itemValue = cmp.getExpressionHelper().getString(itemCfg.get("value", String.class));
    itemAttrs.add("value", itemValue);
    if (selectedValue.equals(itemValue)) {
        itemAttrs.add("selected", true);
    }

    String text = itemCfg.get("text", "");

    %><coral-autocomplete-item <%= itemAttrs.build() %>><%= text %></coral-autocomplete-item><%
}
        if (request.getAttribute("hasBuiltAutocomplete") == null) {
            request.setAttribute("hasBuiltAutocomplete", 1);
        } else {
            request.setAttribute("hasBuiltAutocomplete", (int)request.getAttribute("hasBuiltAutocomplete") + 1);
        }
} else {
    %><coral-autocomplete-item class="workfront-placeholder" data-value="<%= selectedValue %>">Placeholder</coral-autocomplete-item><%
}
%>