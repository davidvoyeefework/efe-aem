<%
%><%@include file="/libs/granite/ui/global.jsp" %><%
%><%@ page session="false" contentType="text/html" pageEncoding="utf-8"
         import="com.adobe.granite.ui.components.formbuilder.FormResourceManager,
         		 org.apache.sling.api.resource.Resource,
                 org.apache.sling.api.resource.ResourceResolver,
				 org.apache.sling.api.resource.SyntheticResource,
                 org.apache.sling.api.resource.ResourceWrapper,
                 org.apache.sling.api.wrappers.ValueMapDecorator,
         		 org.apache.sling.api.resource.ValueMap,
                 com.adobe.granite.ui.components.Config,
		  		 java.util.HashMap,
                 java.util.Map,

                 java.util.Collections"%><%

    ValueMap fieldProperties = resource.adaptTo(ValueMap.class);
    Config cfg = new Config(resource);

    HashMap<String, Object> values = new HashMap<String, Object>();
    values.put("fieldLabel",   i18n.get("Workfront Custom Form Field"));
    values.put("value",        cfg.get("wfCustomFormField", String.class));
    values.put("default",      cfg.get("wfCustomFormField", String.class));
    values.put("name",         "./items/" + resource.getName() + "/wfCustomFormField");

    FormResourceManager formResourceManager = sling.getService(FormResourceManager.class);
    Resource defaultTagFieldResource = formResourceManager.getDefaultPropertyFieldResource(resource, values);
    ParentSyntheticResource wrappedResource = new ParentSyntheticResource(defaultTagFieldResource);
    String tagFieldResPath = defaultTagFieldResource.getPath();
    String datasourceResPath = tagFieldResPath + "/datasource";
    Resource datasourceResource = new SyntheticResourceExtension(resourceResolver, datasourceResPath, "hoodoo-digital/workfront-tools/tools/metadata/workfrontcustomformfields" );
    wrappedResource.addChild("datasource",datasourceResource);

    String optionsResPath = tagFieldResPath + "/options";
    Resource optionsResource = new SyntheticResourceExtension(resourceResolver, optionsResPath, "hoodoo-digital/workfront-tools/tools/components/schemaforms/autocomplete/list" );
    wrappedResource.addChild("options",optionsResource);

%>
<div class="coral-Well">
    <label for="workfrontfields">
        <span class="workfront-label"><%= i18n.get("Workfront Mapping") %></span>
        <sling:include resource="<%= wrappedResource %>" resourceType="hoodoo-digital/workfront-tools/tools/components/schemaforms/autocomplete"/>
        <input class="foundation-field-related" type="hidden" name='<%="./items/"+ resource.getName()  +"/wfCustomFormField@TypeHint"%>' value="String">
<%
    HashMap<String, Object> wfClearWhenEmptyValues = new HashMap<String, Object>();
    wfClearWhenEmptyValues.put("granite:class",     "checkbox-label readonly");
    wfClearWhenEmptyValues.put("text",      i18n.get("Clear value in AEM when value is empty in Workfront"));
    wfClearWhenEmptyValues.put("value",     cfg.get("wfClearWhenEmpty", false));
    wfClearWhenEmptyValues.put("checked",   cfg.get("wfClearWhenEmpty", false));
    wfClearWhenEmptyValues.put("name",      "./items/" + resource.getName() + "/wfClearWhenEmpty");

    Resource wfClearWhenEmptyResource = formResourceManager.getDefaultPropertyFieldResource(resource, wfClearWhenEmptyValues);
%>
        <sling:include resource="<%= wfClearWhenEmptyResource %>" resourceType="granite/ui/components/coral/foundation/form/checkbox"/>
        <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + resource.getName() + "/wfClearWhenEmpty@Delete") %>" value="true">
        <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + resource.getName() + "/wfClearWhenEmpty@TypeHint") %>" value="Boolean">
<%
    HashMap<String, Object> wfGetFromReferenceValues = new HashMap<String, Object>();
    wfGetFromReferenceValues.put("granite:class",     "checkbox-label readonly");
    wfGetFromReferenceValues.put("text",      i18n.get("Get value from Workfront referenced object field"));
    wfGetFromReferenceValues.put("value",     cfg.get("wfGetFromReference", false));
    wfGetFromReferenceValues.put("checked",   cfg.get("wfGetFromReference", false));
    wfGetFromReferenceValues.put("name",      "./items/" + resource.getName() + "/wfGetFromReference");

    Resource wfGetFromReferenceResource = formResourceManager.getDefaultPropertyFieldResource(resource, wfGetFromReferenceValues);
%>
        <sling:include resource="<%= wfGetFromReferenceResource %>" resourceType="granite/ui/components/coral/foundation/form/checkbox"/>
        <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + resource.getName() + "/wfGetFromReference@Delete") %>" value="true">
        <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + resource.getName() + "/wfGetFromReference@TypeHint") %>" value="Boolean">

<%
    HashMap<String, Object> wfReferenceFieldValues = new HashMap<String, Object>();
    wfReferenceFieldValues.put("granite:class", "field-label-descriptor");
    wfReferenceFieldValues.put("fieldLabel",   i18n.get("Referenced Workfront object field"));
    wfReferenceFieldValues.put("value",        cfg.get("wfReferenceField", String.class));
    wfReferenceFieldValues.put("name",         "./items/" + resource.getName() + "/wfReferenceField");

    Resource wfReferenceFieldResource = formResourceManager.getDefaultPropertyFieldResource(resource, wfReferenceFieldValues);
%>
        <sling:include resource="<%= wfReferenceFieldResource %>" resourceType="granite/ui/components/coral/foundation/form/textfield"/>
    </label>
</div>
<%!
private class ParentSyntheticResource extends ResourceWrapper {
    HashMap<String, Resource> childMap;
    Resource parentRes;
    public ParentSyntheticResource(Resource wrappedResource) {
        this(wrappedResource, null);
    }

    public ParentSyntheticResource(Resource wrappedResource, Resource parent) {
        super(wrappedResource);
        parentRes = parent;
        childMap = new HashMap<String, Resource>();
    }

    public void addChild(String relPath, Resource child) {
        childMap.put(relPath, new ParentSyntheticResource(child, this));
    }

    public Resource getChild(String relPath) {
    	return childMap.get(relPath);
    }

    public Resource getParent() {
        return (parentRes != null)? parentRes: super.getParent();
    }
};

public class SyntheticResourceExtension extends SyntheticResource {

    private ValueMap fieldValueMap;

    public SyntheticResourceExtension(ResourceResolver resourceResolver, String path, String resourceType) {
        super(resourceResolver, path, resourceType);
		Map map = Collections.singletonMap("sling:resourceType", resourceType);
        fieldValueMap = new ValueMapDecorator(map);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <AdapterType> AdapterType adaptTo(Class<AdapterType> type) {

        // Return ValueMap of resource Meta
        if (type == ValueMap.class) {
            return (AdapterType) this.fieldValueMap;
        }
        return super.adaptTo(type);
    }

}
%>
