<%
%><%@include file="/libs/granite/ui/global.jsp" %><%
%><%@ page session="false" contentType="text/html" pageEncoding="utf-8"
         import="com.adobe.granite.ui.components.formbuilder.FormResourceManager,
         		 org.apache.sling.api.resource.Resource,
                 org.apache.sling.api.resource.ResourceResolver,
				 org.apache.sling.api.resource.SyntheticResource,
                 org.apache.sling.api.resource.ResourceWrapper,
                 org.apache.sling.api.wrappers.ValueMapDecorator,
         		 org.apache.sling.api.resource.ValueMap,
                 com.adobe.granite.ui.components.Config,
		  		 java.util.HashMap,
                 java.util.Map,

                 java.util.Collections"%><%

    ValueMap fieldProperties = resource.adaptTo(ValueMap.class);
    Config cfg = new Config(resource);

    HashMap<String, Object> values = new HashMap<String, Object>();
    values.put("fieldLabel",   i18n.get("Mapped from Workfront Field"));
    values.put("value",        cfg.get("workfrontField", String.class));
    values.put("default",        cfg.get("workfrontField", String.class));
    values.put("name",         "./items/" + resource.getName() + "/workfrontField");

    FormResourceManager formResourceManager = sling.getService(FormResourceManager.class);
    Resource defaultTagFieldResource = formResourceManager.getDefaultPropertyFieldResource(resource, values);
    ParentSyntheticResource wrappedResource = new ParentSyntheticResource(defaultTagFieldResource);
    String tagFieldResPath = defaultTagFieldResource.getPath();
    String datasourceResPath = tagFieldResPath + "/datasource";
    Resource datasourceResource = new SyntheticResourceExtension(resourceResolver, datasourceResPath, "hoodoo-digital/workfront-tools/tools/metadata/workfrontprojectfields" );
    wrappedResource.addChild("datasource",datasourceResource);

    String optionsResPath = tagFieldResPath + "/options";
    Resource optionsResource = new SyntheticResourceExtension(resourceResolver, optionsResPath, "hoodoo-digital/workfront-tools/tools/components/schemaforms/autocomplete/list" );
    wrappedResource.addChild("options",optionsResource);

%><sling:include resource="<%= wrappedResource %>" resourceType="hoodoo-digital/workfront-tools/tools/components/schemaforms/autocomplete"/>
<input class="foundation-field-related" type="hidden" name='<%="./items/"+ resource.getName()  +"/workfrontField@TypeHint"%>' value="String">
<%!
private class ParentSyntheticResource extends ResourceWrapper {
    HashMap<String, Resource> childMap;
    Resource parentRes;
    public ParentSyntheticResource(Resource wrappedResource) {
        this(wrappedResource, null);
    }

    public ParentSyntheticResource(Resource wrappedResource, Resource parent) {
        super(wrappedResource);
        parentRes = parent;
        childMap = new HashMap<String, Resource>();
    }

    public void addChild(String relPath, Resource child) {
        childMap.put(relPath, new ParentSyntheticResource(child, this));
    }

    public Resource getChild(String relPath) {
    	return childMap.get(relPath);
    }

    public Resource getParent() {
        return (parentRes != null)? parentRes: super.getParent();
    }
};

public class SyntheticResourceExtension extends SyntheticResource {

    private ValueMap fieldValueMap;

    public SyntheticResourceExtension(ResourceResolver resourceResolver, String path, String resourceType) {
        super(resourceResolver, path, resourceType);
		Map map = Collections.singletonMap("sling:resourceType", resourceType);
        fieldValueMap = new ValueMapDecorator(map);
    }

    @SuppressWarnings("unchecked")
    @Override
    public <AdapterType> AdapterType adaptTo(Class<AdapterType> type) {

        // Return ValueMap of resource Meta
        if (type == ValueMap.class) {
            return (AdapterType) this.fieldValueMap;
        }
        return super.adaptTo(type);
    }

}
%>
