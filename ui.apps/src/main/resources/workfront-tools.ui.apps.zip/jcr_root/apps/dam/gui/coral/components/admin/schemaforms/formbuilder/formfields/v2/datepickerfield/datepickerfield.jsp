<%--

  ADOBE CONFIDENTIAL
  __________________

   Copyright 2012 Adobe Systems Incorporated
   All Rights Reserved.

  NOTICE:  All information contained herein is, and remains
  the property of Adobe Systems Incorporated and its suppliers,
  if any.  The intellectual and technical concepts contained
  herein are proprietary to Adobe Systems Incorporated and its
  suppliers and are protected by trade secret or copyright law.
  Dissemination of this information or reproduction of this material
  is strictly forbidden unless prior written permission is obtained
  from Adobe Systems Incorporated.

--%><%
%><%@include file="/libs/granite/ui/global.jsp" %><%
%><%@ page session="false" contentType="text/html" pageEncoding="utf-8"
           import="com.adobe.granite.ui.components.formbuilder.FormResourceManager,
         		 org.apache.sling.api.resource.Resource,
         		 org.apache.sling.api.resource.ValueMap" %><%

    ValueMap fieldProperties = resource.adaptTo(ValueMap.class);
    String key = resource.getName();
	String resourcePathBase = "dam/gui/coral/components/admin/schemaforms/formbuilder/formfieldproperties/";

%>
<div class="formbuilder-content-form">
    <sling:include resource="<%=resource%>" resourceType="granite/ui/components/coral/foundation/form/datepicker"/>
</div>
<div class="formbuilder-content-properties">

    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key) %>">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/jcr:primaryType") %>" value="nt:unstructured">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/resourceType") %>" value="granite/ui/components/coral/foundation/form/datepicker">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/sling:resourceType") %>" value="dam/gui/components/admin/schemafield">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/granite:data/metaType") %>" value="datepicker">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/defaultDateField") %>">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/value@TypeHint") %>" value="Date">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/granite:data/typeHint") %>" value="Date">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/type") %>" value="datetime">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/displayedFormat") %>" value="YYYY-MM-DD HH:mm"/>
    <%
    if (fieldProperties.containsKey("minDate")) {
    	%><input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/minDate") %>" value="<%= xssAPI.encodeForHTMLAttr(fieldProperties.get("minDate", String.class)) %>"/><%
    }
    if (fieldProperties.containsKey("maxDate")) {
    	%><input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/maxDate") %>" value="<%= xssAPI.encodeForHTMLAttr(fieldProperties.get("maxDate", String.class)) %>"/><%
    }
    %>

    <%
        String[] settingsList = {"labelfields", "metadatamappertextfield", "titlefields", "wfcustomformfields"};
        for(String settingComponent : settingsList){
            %>
                <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + settingComponent %>"/>
            <%
        }
    %>

    <coral-icon class="delete-field" icon="delete" size="L" href="" data-target-id="<%= xssAPI.encodeForHTMLAttr(key) %>" data-target="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "@Delete") %>"></coral-icon>

</div>
<div class="formbuilder-content-properties-rules">
    <label for="field">
    	<span class="rules-label"><%= i18n.get("Field") %></span>
        <%
            String[] fieldRulesList = {"disableineditmodefields", "showemptyfieldinreadonly"};
            for(String ruleComponent : fieldRulesList){
                %>
                    <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + ruleComponent %>"/>
                <%
            }

        %>
    </label>
    <label for="requirement">
    	<span class="rules-label"><%= i18n.get("Requirement") %></span>
        <% String requiredField = "v2/requiredfields"; %>
        <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + requiredField %>"/>
    </label>
    <label for="visibililty">
        <span class="rules-label"><%= i18n.get("Visibility") %></span>
        <% String visibilityField = "visibilityfields"; %>
        <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + visibilityField %>"/>
    </label>
</div>
