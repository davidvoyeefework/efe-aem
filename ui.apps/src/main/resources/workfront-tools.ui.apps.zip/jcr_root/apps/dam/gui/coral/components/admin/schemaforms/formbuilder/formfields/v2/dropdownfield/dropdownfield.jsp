<%--

  ADOBE CONFIDENTIAL
  __________________

   Copyright 2012 Adobe Systems Incorporated
   All Rights Reserved.

  NOTICE:  All information contained herein is, and remains
  the property of Adobe Systems Incorporated and its suppliers,
  if any.  The intellectual and technical concepts contained
  herein are proprietary to Adobe Systems Incorporated and its
  suppliers and are protected by trade secret or copyright law.
  Dissemination of this information or reproduction of this material
  is strictly forbidden unless prior written permission is obtained
  from Adobe Systems Incorporated.

--%><%
%><%@include file="/libs/granite/ui/global.jsp" %><%
%><%@ page session="false" contentType="text/html" pageEncoding="utf-8"
           import="com.adobe.granite.ui.components.formbuilder.FormResourceManager,
                   com.adobe.granite.ui.components.ds.ValueMapResource,
                   org.apache.sling.api.resource.Resource,
                   org.apache.sling.api.wrappers.ValueMapDecorator,
                   org.apache.commons.io.IOUtils,
                   org.apache.sling.api.resource.ResourceMetadata,
                   org.apache.jackrabbit.util.Text,
                   java.util.Iterator" %><%

    String key = resource.getName();
    String resourcePathBase = "dam/gui/coral/components/admin/schemaforms/formbuilder/formfieldproperties/";
%>
<div class="formbuilder-content-form">
    <sling:include resource="<%=resource%>" resourceType="dam/gui/coral/components/admin/schemaforms/formbuilder/formfields/v2/metadataselect" addSelectors="quiet"/>
</div>

<div class="formbuilder-content-properties">

    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key) %>">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/jcr:primaryType") %>" value="nt:unstructured">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/resourceType") %>" value="dam/gui/coral/components/admin/schemaforms/formbuilder/formfields/v2/metadataselect">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/sling:resourceType") %>" value="dam/gui/components/admin/schemafield">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/granite:data/metaType") %>" value="dropdown">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/items") %>">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/items/jcr:primaryType") %>" value="nt:unstructured">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/value") %>" value="">
    <input type="hidden" name="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "/emptyText") %>" value="<%=i18n.get("Select Option")%>">

    <%
        String[] settingsList = {"labelfields", "metadatamappertextfield", "wfcustomformfields"};
        for(String settingComponent : settingsList){
            %>
                <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + settingComponent %>"/>
            <%
        }
    %>
    <sling:include resource="<%= resource %>" resourceType="dam/gui/coral/components/admin/schemaforms/formbuilder/formfieldproperties/titlefields"/>

    <%
    ValueMap properties = resource.adaptTo(ValueMap.class);
    String jsonPath = properties.get("jsonPath", String.class);
    boolean hasJsonPath = jsonPath != null && !jsonPath.isEmpty();
    %>

    <div class="dropdown">
    <span><%= xssAPI.encodeForHTML(i18n.get("Choices")) %></span>
    <div class="choice-radio-div">
        <table class="coral-Table">
            <tr class="coral-Table-row">
                <td class="coral-Table-cell">
                    <label>
                        <input type="radio" name="choice-options" class="radio-choice-manual" key="<%= key %>" <%= hasJsonPath ? "" : "checked" %>>
                        <span style="margin-left: 0.5rem;"><%= xssAPI.encodeForHTML(i18n.get("Add Manually")) %></span>
                    </label>
                </td>
                <td class="coral-Table-cell" data-foobar="<%= hasJsonPath %>">
                    <label>
                        <input type="radio" name="choice-options" class="radio-choice-json" key="<%= key %>" <%= hasJsonPath ? "checked" : "" %>>
                        <span style="margin-left: 0.5rem;"><%= xssAPI.encodeForHTML(i18n.get("Add through JSON path")) %></span>
                    </label>
                </td>
            </tr>
        </table>
    </div>
    <div class="choice-values-manual" key=<%= key %> <%= hasJsonPath ? "hidden" : "" %>>
        <div class="add-from-json-wrapper">
            <input is="coral-textfield" type="text" placeholder="<%= xssAPI.encodeForHTML(i18n.get("Add from JSON")) %>" class="add-from-json-field"/>
            <button type="button" is="coral-button" class="add-from-json-btn" disabled>
                <%= xssAPI.encodeForHTML(i18n.get("Add")) %>
            </button>
        </div>
            <table class="coral-Table members-table dropdown-options"
                   id="<%= xssAPI.encodeForHTMLAttr("list-" + key) %>"
                   data-list-id="<%= xssAPI.encodeForHTMLAttr(key) %>" selectable>
                <tbody class="coral-Table-body">
                <%
                    Resource jsonResource = resourceResolver.getResource(jsonPath);
                    if (jsonResource == null && resource.getChild("items") != null) {
                        Iterator<Resource> formfields = resource.getChild("items").listChildren();
                        while (formfields.hasNext()) {
                            Resource itemResource = formfields.next();
                            %><sling:include resource="<%= itemResource %>"
                                    resourceType="dam/gui/coral/components/admin/schemaforms/formbuilder/formfields/v2/dropdownfield/dropdownitem"/><%
                        }
                    }
                %>
                <tr class="coral-Table-row">
                    <%--Empty column to align the width with radio buttons--%>
                    <td class="coral-Table-cell" style="border: none !important;background: none !important;"></td>
                    <td class="coral-Table-cell append-dropdown-td">
                        <button is="coral-button" class="append-dropdown-option" icon="addCircle" iconsize="S"
                                data-value="<%= xssAPI.encodeForHTMLAttr("template-option-" + key) %>"
                                data-target="<%= xssAPI.encodeForHTMLAttr("list-" + key) %>"
                                data-target-parent="<%= xssAPI.encodeForHTMLAttr(key) %>"><%= xssAPI.encodeForHTML(i18n.get("Add Choice")) %>
                        </button>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <div class="choice-values-json" key=<%= key %> <%= hasJsonPath ? "" : "hidden" %>>
        <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + "jsonfields" %>"/>
    </div>

    <coral-icon class="delete-field" icon="delete" size="L" href="" data-target-id="<%= xssAPI.encodeForHTMLAttr(key) %>" data-target="<%= xssAPI.encodeForHTMLAttr("./items/" + key + "@Delete") %>"></coral-icon>

</div>
<div class="formbuilder-content-properties-rules">
    <label for="field">
        <span id="field" class="rules-label"><%= i18n.get("Field") %></span>
        <%
            String[] fieldRulesList = {"disableineditmodefields", "multivalue", "showemptyfieldinreadonly", "orderedlist"};
            for(String ruleComponent : fieldRulesList){
                %>
                    <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + ruleComponent %>"/>
                <%
            }

        %>
    </label>
    <label for="requirement">
        <span class="rules-label"><%= i18n.get("Requirement") %></span>
        <% String requiredField = "v2/requiredfields"; %>
        <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + requiredField %>"/>
    </label>
    <label for="visibililty" class="manual-options-only" <%= hasJsonPath ? "hidden" : "" %>>
        <span class="rules-label"><%= i18n.get("Visibility") %></span>
        <% String visibilityField = "visibilityfields"; %>
        <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + visibilityField %>"/>
    </label>
    <label for="choices" class="manual-options-only" <%= hasJsonPath ? "hidden" : "" %>>
        <span class="rules-label"><%= i18n.get("Choices") %></span>
        <% String choiceField = "choicefield"; %>
        <sling:include resource="<%= resource %>" resourceType="<%= resourcePathBase + choiceField %>"/>
    </label>
</div>